import { NextRequest, NextResponse } from "next/server";
import { ToolkitExecution, NormalizedFinding } from "@/lib/types";

export const runtime = "nodejs";

// Server-side in-memory store for toolkit data
// In a full production build, this maps to a DB table (e.g., supabase database tables)
const executionsStore = new Map<string, ToolkitExecution[]>();
const findingsStore = new Map<string, NormalizedFinding[]>();

// ── GET: Fetch execution history and findings by case reference ──────────────
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const caseRef = searchParams.get("case");

  if (!caseRef) {
    return NextResponse.json({ error: "case parameter is required" }, { status: 400 });
  }

  const executions = executionsStore.get(caseRef) || [];
  const findings = findingsStore.get(caseRef) || [];

  return NextResponse.json({
    caseReference: caseRef,
    executions,
    findings,
    count: findings.length,
  });
}

// ── POST: Record execution and findings ──────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { caseReference, executions, findings } = body;

    if (!caseReference) {
      return NextResponse.json({ error: "caseReference is required" }, { status: 400 });
    }

    // Update executions
    if (Array.isArray(executions)) {
      const existingExecs = executionsStore.get(caseReference) || [];
      // Prevent duplicates by checking execution ID
      const newExecs = executions.filter(e => !existingExecs.some(ex => ex.id === e.id));
      executionsStore.set(caseReference, [...existingExecs, ...newExecs].slice(0, 100)); // cap at 100 logs
    }

    // Update findings
    if (Array.isArray(findings)) {
      const existingFindings = findingsStore.get(caseReference) || [];
      const newFindings = findings.filter(f => !existingFindings.some(fi => fi.id === f.id));
      findingsStore.set(caseReference, [...existingFindings, ...newFindings].slice(0, 500)); // cap at 500 findings
    }

    return NextResponse.json({
      success: true,
      caseReference,
      executions: executionsStore.get(caseReference) || [],
      findings: findingsStore.get(caseReference) || [],
    });
  } catch (err) {
    console.error("[toolkit POST] Error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to record toolkit execution." },
      { status: 500 }
    );
  }
}
