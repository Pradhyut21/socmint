import { OsintProvider } from "./index";
import { NormalizedFinding } from "../../types";

export const epieosProvider: OsintProvider & {
  lookupEmail(email: string): Promise<string>;
  lookupPhone(phone: string): Promise<string>;
  lookupUsername(username: string): Promise<string>;
} = {
  id: "epieos",
  name: "Epieos",
  supportedInputs: ["email", "phone", "username"],
  overview: "Epieos is a search platform that performs passive intelligence collection across Google accounts, social profiles, and registered email handles. In SOCMINT Shield, Epieos operates as a manual, analyst-directed intelligence provider.",
  capabilities: [
    "Identifies Google account avatars, profile names, and maps calendar availability",
    "Checks profile registrations linked to email addresses",
    "Locates open social connections associated with handles"
  ],
  installation: "Integrated as a compliant manual research and import workflow inside SOCMINT Shield.",
  compliance: {
    supported: [
      "Manual redirect to official lookup interface",
      "Analyst-verified import of public record findings",
      "Corroborative cross-platform signal checks"
    ],
    restricted: [
      "Website scraping or automatic browser actions",
      "Automation or script execution against epieos.com",
      "Credential bypass or session hijacking",
      "Reverse engineering Epieos endpoints"
    ],
    safeAlternative: "SOCMINT Shield intentionally performs analyst-assisted manual redirects and import operations, enforcing strict adherence to terms of service.",
    socmintShieldIntegration: "Analyst runs lookups on Epieos directly and imports findings manually. The platform validates, scores, and stamps integrity hashes."
  },
  async execute(input: string, onLog?: (log: string) => void): Promise<any> {
    if (onLog) {
      onLog(`[*] Epieos v1.0 Integration`);
      onLog(`[*] Target identifier: "${input}"`);
      onLog(`[!] Official API not configured. Please use the Manual Lookup tab to complete search.`);
    }
    throw new Error("Official API not configured.");
  },
  async normalize(raw: any, input: string): Promise<NormalizedFinding[]> {
    const timestamp = new Date().toISOString();
    
    // Check if raw data has fields from the manual import form
    if (!raw) return [];
    
    const findings: NormalizedFinding[] = [];
    
    // Helper to map confidence strings to numbers
    const parseConfidence = (confStr: string): number => {
      if (confStr === "high") return 0.95;
      if (confStr === "medium") return 0.70;
      return 0.40;
    };
    
    const confidenceVal = typeof raw.confidence === "number" ? raw.confidence : parseConfidence(raw.confidence || "medium");

    // 1. Generate identity finding if name is provided
    if (raw.displayName) {
      findings.push({
        id: `epieos-identity-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: "Epieos Identity Mapped",
        description: `Name: "${raw.displayName}". Company: "${raw.company || 'N/A'}". Region: "${raw.region || raw.country || 'N/A'}"`,
        source: "Epieos Google Profile Search",
        url: raw.sourceUrl || null,
        confidence: confidenceVal,
        category: "External Intelligence",
        entity: input,
        provider: "Epieos",
        timestamp,
      });
    }

    // 2. Generate profile finding if profileUrl is provided
    if (raw.profileUrl) {
      findings.push({
        id: `epieos-profile-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: "Epieos Profile Reference Discovered",
        description: `Discovered profile registration link: ${raw.profileUrl}. Notes: ${raw.notes || "None."}`,
        source: "Epieos Profile Discovery",
        url: raw.profileUrl,
        confidence: confidenceVal,
        category: "External Intelligence",
        entity: input,
        provider: "Epieos",
        timestamp,
      });
    }

    // 3. Fallback general finding if neither name nor profile is provided but notes exist
    if (findings.length === 0 && raw.notes) {
      findings.push({
        id: `epieos-notes-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: "Epieos Manual Investigation Record",
        description: `Notes: ${raw.notes}`,
        source: "Epieos Manual Import",
        url: raw.sourceUrl || null,
        confidence: confidenceVal,
        category: "External Intelligence",
        entity: input,
        provider: "Epieos",
        timestamp,
      });
    }

    return findings;
  },
  
  // Future API Readiness helper functions
  async lookupEmail(email: string): Promise<string> {
    return "Official API not configured.";
  },
  async lookupPhone(phone: string): Promise<string> {
    return "Official API not configured.";
  },
  async lookupUsername(username: string): Promise<string> {
    return "Official API not configured.";
  }
};
