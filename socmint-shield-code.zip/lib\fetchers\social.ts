import { PlatformAccount, Post, SuspectProfile } from "../types";
import { getDemoProbeResult, getDemoGithubData } from "../mock/demoData";

export type ProbeResult = {
  ok: boolean;
  status?: number;
  title?: string;
  description?: string;
  verifiedUsername?: string;
  verifiedUrl?: string;
};

export type PlatformProbe = {
  platform: PlatformAccount["platform"];
  label: string;
  url: (username: string) => string;
  normalize?: (username: string) => string;
  tier: 1 | 2;
};

export const PLATFORM_PROBES: PlatformProbe[] = [
  // Tier 1 — Official APIs
  { tier: 1, platform: "github",    label: "GitHub",     url: (u) => `https://github.com/${u}` },
  { tier: 1, platform: "reddit",    label: "Reddit",     url: (u) => `https://www.reddit.com/user/${u}` },
  { tier: 1, platform: "hackernews",label: "HackerNews", url: (u) => `https://news.ycombinator.com/user?id=${u}` },
  { tier: 1, platform: "devto",     label: "Dev.to",     url: (u) => `https://dev.to/${u}` },
  { tier: 1, platform: "gitlab",    label: "GitLab",     url: (u) => `https://gitlab.com/${u}` },
  { tier: 1, platform: "tumblr",    label: "Tumblr",     url: (u) => `https://${u}.tumblr.com` },
  // Tier 2 — HTTP existence probes
  { tier: 2, platform: "twitter",   label: "X / Twitter",url: (u) => `https://x.com/${u}` },
  { tier: 2, platform: "instagram", label: "Instagram",  url: (u) => `https://www.instagram.com/${u}` },
  { tier: 2, platform: "facebook",  label: "Facebook",   url: (u) => `https://www.facebook.com/${u}` },
  { tier: 2, platform: "telegram",  label: "Telegram",   url: (u) => `https://t.me/${u}` },
  { tier: 2, platform: "linkedin",  label: "LinkedIn",   normalize: (u) => u.replace(/^in\//, "").replace(/_/g, "-"), url: (u) => `https://www.linkedin.com/in/${u}` },
  { tier: 2, platform: "tiktok",    label: "TikTok",     url: (u) => `https://www.tiktok.com/@${u}` },
  { tier: 2, platform: "snapchat",  label: "Snapchat",   url: (u) => `https://www.snapchat.com/add/${u}` },
  { tier: 2, platform: "pinterest", label: "Pinterest",  url: (u) => `https://www.pinterest.com/${u}` },
  { tier: 2, platform: "soundcloud",label: "SoundCloud", url: (u) => `https://soundcloud.com/${u}` },
  { tier: 2, platform: "medium",    label: "Medium",     url: (u) => `https://medium.com/@${u}` },
  { tier: 2, platform: "quora",     label: "Quora",      url: (u) => `https://www.quora.com/profile/${u}` },
  { tier: 2, platform: "steam",     label: "Steam",      url: (u) => `https://steamcommunity.com/id/${u}` },
  { tier: 2, platform: "pastebin",  label: "Pastebin",   url: (u) => `https://pastebin.com/u/${u}` },
  { tier: 2, platform: "youtube",   label: "YouTube",    url: (u) => `https://www.youtube.com/@${u}` },
];

export const RISK_TERMS = [
  "fraud", "scam", "hawala", "mule", "otp", "carding", "crypto",
  "cash drop", "bypass", "leak", "stolen", "session", "escrow",
  "mirror payment", "phishing", "ransomware", "darkweb", "dark web",
  "hacking", "exploit", "keylogger", "ddos", "botnet", "deepfake",
  "money laundering", "shell company", "fake kyc", "sim swap",
];

export function cleanQuery(query: string) {
  return query.trim().replace(/^@/, "").replace(/\s+/g, "");
}

export function scoreText(text: string) {
  const haystack = text.toLowerCase();
  return RISK_TERMS.reduce((score, term) => score + (haystack.includes(term) ? 1 : 0), 0);
}

export function confidenceFor(platform: string, query: string, result: ProbeResult): PlatformAccount["confidence"] {
  if (platform === "github" || platform === "reddit" || platform === "hackernews" || platform === "devto" || platform === "gitlab") {
    return "CONFIRMED";
  }
  if (result.ok && result.title?.toLowerCase().includes(query.toLowerCase())) return "PROBABLE";
  return "POSSIBLE";
}

export function displayNameFromQuery(query: string) {
  const cleaned = query.trim().replace(/^@/, "");
  if (!cleaned) return "Unknown Public Subject";
  return cleaned
    .split(/[._\-\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export async function fetchWithTimeout(url: string, timeoutMs = 5500): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Sec-Ch-Ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
      },
    });
  } finally {
    clearTimeout(timeout);
  }
}

export function parseHandlesFromBio(bio: string): { platform: string; username: string }[] {
  const found: { platform: string; username: string }[] = [];
  const lowercaseBio = bio.toLowerCase();
  
  const platforms = [
    { name: "instagram", keywords: ["instagram", "ig", "insta"] },
    { name: "twitter", keywords: ["twitter", "x.com", "x:"] },
    { name: "linkedin", keywords: ["linkedin", "li:"] },
    { name: "reddit", keywords: ["reddit", "u/"] },
    { name: "medium", keywords: ["medium"] },
  ];
  
  for (const plat of platforms) {
    for (const keyword of plat.keywords) {
      const idx = lowercaseBio.indexOf(keyword);
      if (idx !== -1) {
        const after = bio.slice(idx + keyword.length);
        const match = after.match(/(?:[:\s\-@=]+)([a-zA-Z0-9_\.]+)/);
        if (match && match[1]) {
          const resolved = match[1].trim();
          if (resolved && resolved.length > 2 && !["com", "http", "https"].includes(resolved.toLowerCase())) {
            found.push({ platform: plat.name, username: resolved });
          }
        }
      }
    }
  }
  return found;
}

export function buildExpandedSearchQuery(query: string): string {
  const cleaned = query.trim().replace(/^@/, "");
  if (!cleaned) return "";

  if (/^\+?\d{10,15}$/.test(cleaned) || cleaned.includes("@") || (cleaned.startsWith("0x") && cleaned.length === 42)) {
    return cleaned;
  }

  const parts = cleaned.split(/[_\-\s]+/);
  if (parts.length > 1) {
    const spaceVariant = parts.join(" ");
    const hyphenVariant = parts.join("-");
    const underscoreVariant = parts.join("_");
    const concatVariant = parts.join("");
    return `("${spaceVariant}" OR "${hyphenVariant}" OR "${underscoreVariant}" OR "${concatVariant}")`;
  }

  return cleaned;
}

export function levenshteinDistance(a: string, b: string): number {
  const la = a.length, lb = b.length;
  const dp: number[][] = Array.from({ length: la + 1 }, (_, i) =>
    Array.from({ length: lb + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= la; i++) {
    for (let j = 1; j <= lb; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[la][lb];
}

export function extractMeta(html: string, pattern: RegExp): string {
  const match = html.match(pattern);
  return match && match[1] ? match[1].trim() : "";
}

export async function verifyProfileExistsViaSearch(platform: string, username: string): Promise<string | null> {
  try {
    const lowerUser = username.toLowerCase();
    const lowerPlatform = platform.toLowerCase();

    let searchUrl = `https://www.google.com/search?q=site:${platform}.com/${username}&num=5`;
    if (lowerPlatform === "linkedin") {
      const cleanUser = lowerUser.replace(/[._]/g, "-");
      const hyphenated = cleanUser;
      const concat = lowerUser.replace(/[._\-]/g, "");
      searchUrl = `https://www.google.com/search?q=${encodeURIComponent(`("${hyphenated}" OR "${concat}") site:linkedin.com/in/`)}&num=5`;
    } else if (lowerPlatform === "telegram") {
      searchUrl = `https://www.google.com/search?q=${encodeURIComponent(`site:t.me/${username} OR "t.me/${username}"`)}&num=5`;
    } else if (lowerPlatform === "youtube") {
      searchUrl = `https://www.google.com/search?q=${encodeURIComponent(`site:youtube.com/@${username} OR site:youtube.com/user/${username} OR site:youtube.com/c/${username}`)}&num=5`;
    } else if (lowerPlatform === "facebook") {
      searchUrl = `https://www.google.com/search?q=${encodeURIComponent(`site:facebook.com/${username}`)}&num=5`;
    }
    const resp = await fetchWithTimeout(searchUrl, 4500);
    if (resp.ok) {
      const html = await resp.text();
      const blocks = html.split(/<div[^>]*class="[^"]*(?<![a-zA-Z0-9-])g(?![a-zA-Z0-9-])[^"]*"/gi);
      
      for (let i = 1; i < blocks.length; i++) {
        const block = blocks[i];
        const urlMatch = block.match(/href="(\/url\?[^"]+)"/i) || block.match(/href="(https?:\/\/[^"]+)"/i);
        if (urlMatch) {
          let decodedUrl = "";
          const rawUrl = urlMatch[1];
          if (rawUrl.startsWith("/url?")) {
            const qMatch = rawUrl.match(/[?&]q=([^&"]+)/);
            if (qMatch) {
              try {
                decodedUrl = decodeURIComponent(qMatch[1]).toLowerCase();
              } catch (e) {}
            }
          }
          if (!decodedUrl && rawUrl.startsWith('http') && !rawUrl.includes('google.com')) {
            decodedUrl = rawUrl.toLowerCase();
          }

          if (lowerPlatform === "linkedin") {
            const cleanUser = lowerUser.replace(/[._]/g, "-");
            const hyphenated = cleanUser;
            const concat = lowerUser.replace(/[._\-]/g, "");
            if (decodedUrl.includes(`linkedin.com/in/${hyphenated}`)) {
              return hyphenated;
            }
            if (decodedUrl.includes(`linkedin.com/in/${concat}`)) {
              return concat;
            }
          } else if (lowerPlatform === "telegram") {
            if (decodedUrl.includes(`t.me/${lowerUser}`) || decodedUrl.includes(`telegram.me/${lowerUser}`)) {
              return username;
            }
          } else if (lowerPlatform === "youtube") {
            if (decodedUrl.includes(`youtube.com/@${lowerUser}`) || decodedUrl.includes(`youtube.com/user/${lowerUser}`) || decodedUrl.includes(`youtube.com/c/${lowerUser}`)) {
              return username;
            }
          } else if (lowerPlatform === "facebook") {
            if (decodedUrl.includes(`facebook.com/${lowerUser}`) || decodedUrl.includes(`facebook.com/profile.php`)) {
              return username;
            }
          } else {
            if (decodedUrl.includes(`${lowerPlatform}.com/${lowerUser}`)) {
              return username;
            }
          }
        }
      }
    }
  } catch {
    // ignore
  }
  return null;
}

export async function probePublicProfile(url: string): Promise<ProbeResult> {
  const lowercaseUrl = url.toLowerCase();

  // Delegate demo user probe overrides to the demo data module
  const demoResult = getDemoProbeResult(lowercaseUrl);
  if (demoResult) return demoResult;

  try {
    const response = await fetchWithTimeout(url);
    if (!response.ok) {
      if (response.status === 429 || response.status === 999 || response.status === 403) {
        const platformName = lowercaseUrl.includes("instagram.com") ? "instagram"
          : lowercaseUrl.includes("twitter.com") || lowercaseUrl.includes("x.com") ? "twitter"
          : lowercaseUrl.includes("linkedin.com") ? "linkedin"
          : lowercaseUrl.includes("t.me") ? "telegram"
          : lowercaseUrl.includes("facebook.com") ? "facebook"
          : lowercaseUrl.includes("youtube.com") ? "youtube"
          : "";
        if (platformName) {
          let usernamePart = "";
          if (platformName === "linkedin") {
            usernamePart = lowercaseUrl.split("linkedin.com/in/")[1]?.split("/")[0]?.split("?")[0] || "";
          } else if (platformName === "telegram") {
            usernamePart = lowercaseUrl.split("t.me/")[1]?.split("/")[0]?.split("?")[0] || "";
          } else if (platformName === "youtube") {
            const splitAt = lowercaseUrl.includes("youtube.com/@") ? "youtube.com/@" : "youtube.com/";
            usernamePart = lowercaseUrl.split(splitAt)[1]?.split("/")[0]?.split("?")[0] || "";
            if (usernamePart === "user" || usernamePart === "c" || usernamePart === "channel") {
              usernamePart = lowercaseUrl.split("youtube.com/")[1]?.split("/")[1]?.split("?")[0] || "";
            }
          } else {
            usernamePart = lowercaseUrl.split(`${platformName}.com/`)[1]?.split("/")[0]?.split("?")[0] || "";
          }
          if (usernamePart) {
            const verifiedUsername = await verifyProfileExistsViaSearch(platformName, usernamePart);
            if (verifiedUsername) {
              const verifiedUrl = platformName === "linkedin" ? `https://www.linkedin.com/in/${verifiedUsername}` : lowercaseUrl;
              return { ok: true, status: 200, title: `${verifiedUsername} on ${platformName}`, description: `Public profile found and verified via search indexing.`, verifiedUsername, verifiedUrl };
            }
          }
        }
      }
      return { ok: response.status < 400, status: response.status };
    }

    const html = await response.text();
    const title = extractMeta(html, /<title[^>]*>([^<]+)<\/title>/i);
    const description =
      extractMeta(html, /<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i) ||
      extractMeta(html, /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i);

    const lowerTitle = title?.toLowerCase() || "";
    
    // Check for login redirects or authorization checks
    if (lowerTitle.includes("login") || lowerTitle.includes("sign in") || lowerTitle.includes("log in") || lowerTitle.includes("sign up") || lowerTitle.includes("register") || lowerTitle.includes("authorize") || lowerTitle.includes("sign-in")) {
      const platformName = lowercaseUrl.includes("instagram.com") ? "instagram"
        : lowercaseUrl.includes("twitter.com") || lowercaseUrl.includes("x.com") ? "twitter"
        : lowercaseUrl.includes("linkedin.com") ? "linkedin"
        : lowercaseUrl.includes("facebook.com") ? "facebook"
        : lowercaseUrl.includes("youtube.com") ? "youtube"
        : "";
      if (platformName) {
        let usernamePart = "";
        if (platformName === "linkedin") {
          usernamePart = lowercaseUrl.split("linkedin.com/in/")[1]?.split("/")[0]?.split("?")[0] || "";
        } else if (platformName === "youtube") {
          const splitAt = lowercaseUrl.includes("youtube.com/@") ? "youtube.com/@" : "youtube.com/";
          usernamePart = lowercaseUrl.split(splitAt)[1]?.split("/")[0]?.split("?")[0] || "";
          if (usernamePart === "user" || usernamePart === "c" || usernamePart === "channel") {
            usernamePart = lowercaseUrl.split("youtube.com/")[1]?.split("/")[1]?.split("?")[0] || "";
          }
        } else {
          usernamePart = lowercaseUrl.split(`${platformName}.com/`)[1]?.split("/")[0]?.split("?")[0] || "";
        }
        if (usernamePart) {
          const verifiedUsername = await verifyProfileExistsViaSearch(platformName, usernamePart);
          if (verifiedUsername) {
            const verifiedUrl = platformName === "linkedin" ? `https://www.linkedin.com/in/${verifiedUsername}` : lowercaseUrl;
            return { ok: true, status: 200, title: `${verifiedUsername} on ${platformName}`, description: `Public profile found and verified via search indexing.`, verifiedUsername, verifiedUrl };
          }
        }
      }
      return { ok: false, status: response.status, title, description };
    }
    
    // Check for generic homepage landing page titles (indicating redirects)
    const genericTitles = [
      "twitter", "instagram", "facebook", "reddit: the front page of the internet",
      "reddit - dive into anything", "pinterest", "tumblr", "soundcloud", "medium", "steam community",
      "telegram", "telegram web", "youtube",
    ];
    if (genericTitles.some(gt => lowerTitle === gt || lowerTitle.startsWith(gt + " - ") || lowerTitle.endsWith(" | log in") || lowerTitle.endsWith(" | sign in"))) {
      const platformName = lowercaseUrl.includes("instagram.com") ? "instagram"
        : lowercaseUrl.includes("twitter.com") || lowercaseUrl.includes("x.com") ? "twitter"
        : lowercaseUrl.includes("linkedin.com") ? "linkedin"
        : lowercaseUrl.includes("t.me") ? "telegram"
        : lowercaseUrl.includes("facebook.com") ? "facebook"
        : lowercaseUrl.includes("youtube.com") ? "youtube"
        : "";
      if (platformName) {
        let usernamePart = "";
        if (platformName === "linkedin") {
          usernamePart = lowercaseUrl.split("linkedin.com/in/")[1]?.split("/")[0]?.split("?")[0] || "";
        } else if (platformName === "telegram") {
          usernamePart = lowercaseUrl.split("t.me/")[1]?.split("/")[0]?.split("?")[0] || "";
        } else if (platformName === "youtube") {
          const splitAt = lowercaseUrl.includes("youtube.com/@") ? "youtube.com/@" : "youtube.com/";
          usernamePart = lowercaseUrl.split(splitAt)[1]?.split("/")[0]?.split("?")[0] || "";
          if (usernamePart === "user" || usernamePart === "c" || usernamePart === "channel") {
            usernamePart = lowercaseUrl.split("youtube.com/")[1]?.split("/")[1]?.split("?")[0] || "";
          }
        } else {
          usernamePart = lowercaseUrl.split(`${platformName}.com/`)[1]?.split("/")[0]?.split("?")[0] || "";
        }
        if (usernamePart) {
          const verifiedUsername = await verifyProfileExistsViaSearch(platformName, usernamePart);
          if (verifiedUsername) {
            const verifiedUrl = platformName === "linkedin" ? `https://www.linkedin.com/in/${verifiedUsername}` : lowercaseUrl;
            return { ok: true, status: 200, title: `${verifiedUsername} on ${platformName}`, description: `Public profile found and verified via search indexing.`, verifiedUsername, verifiedUrl };
          }
        }
      }
      return { ok: false, status: response.status, title, description };
    }

    return {
      ok: !/not found|page doesn't exist|this account doesn't exist|404|no such user/i.test(`${title} ${description} ${html}`),
      status: response.status,
      title,
      description,
    };
  } catch {
    return { ok: false };
  }
}

export function formatGithubEvent(event: any): Post {
  let content = `${event.type?.replace("Event", "") || "Activity"} activity on ${event.repo?.name || "a public repository"}`;
  
  if (event.type === "PushEvent" && event.payload?.commits) {
    const commits = event.payload.commits;
    if (Array.isArray(commits) && commits.length > 0) {
      const commitMsgs = commits.slice(0, 3).map((c: any) => `'${c.message || ""}'`).join(", ");
      const moreStr = commits.length > 3 ? ` and ${commits.length - 3} more` : "";
      content = `Pushed ${commits.length} commit${commits.length > 1 ? "s" : ""} to ${event.repo?.name || "repository"}: ${commitMsgs}${moreStr}`;
    } else {
      content = `Pushed commits to ${event.repo?.name || "repository"}`;
    }
  } else if (event.type === "CreateEvent") {
    content = `Created ${event.payload?.ref_type || "repository"} ${event.payload?.ref || ""} in ${event.repo?.name || "a public repository"}`;
  } else if (event.type === "PullRequestEvent") {
    content = `${event.payload?.action || "Opened"} Pull Request #${event.payload?.number || ""} in ${event.repo?.name || "repository"}`;
  } else if (event.type === "IssuesEvent") {
    content = `${event.payload?.action || "Opened"} issue #${event.payload?.issue?.number || ""} in ${event.repo?.name || "repository"}`;
  }
  
  return {
    id: `github-${event.id}`,
    platform: "github",
    content,
    postedAt: event.created_at,
    flagLevel: "NORMAL",
    capturedAt: new Date().toISOString(),
  };
}

export async function fuzzyGithubSearch(username: string): Promise<{ account?: Partial<PlatformAccount>; posts: Post[]; resolvedUsername?: string }> {
  try {
    const searchResp = await fetchWithTimeout(
      `https://api.github.com/search/users?q=${encodeURIComponent(username)}+in:login&per_page=5`,
      7000
    );
    if (!searchResp.ok) return { posts: [] };
    const searchData = await searchResp.json();

    if (!searchData.items || searchData.items.length === 0) return { posts: [] };

    const lowerQuery = username.toLowerCase();
    const ranked = searchData.items
      .map((item: any) => ({
        login: item.login as string,
        distance: levenshteinDistance(lowerQuery, (item.login as string).toLowerCase()),
        avatarUrl: item.avatar_url as string,
      }))
      .sort((a: { distance: number }, b: { distance: number }) => a.distance - b.distance);

    const maxDistance = lowerQuery.length <= 5 ? 1 : lowerQuery.length <= 9 ? 2 : 3;
    const bestMatch = ranked[0];
    if (!bestMatch || bestMatch.distance > maxDistance) return { posts: [] };

    const resolvedUsername = bestMatch.login;
    console.log(`[SOCMINT] Fuzzy match: "${username}" → "${resolvedUsername}" (edit distance: ${bestMatch.distance})`);

    const [userResp, eventsResp] = await Promise.all([
      fetchWithTimeout(`https://api.github.com/users/${resolvedUsername}`),
      fetchWithTimeout(`https://api.github.com/users/${resolvedUsername}/events/public?per_page=5`),
    ]);

    if (!userResp.ok) return { posts: [] };

    const user = await userResp.json();
    const events = eventsResp.ok ? await eventsResp.json() : [];

    const posts: Post[] = Array.isArray(events)
      ? events.slice(0, 5).map((event: any) => formatGithubEvent(event))
      : [];

    return {
      account: {
        displayName: user.name || user.login,
        bio: user.bio || "Public GitHub profile found. No bio exposed.",
        profilePicUrl: user.avatar_url,
        followers: user.followers || 0,
        creationDate: user.created_at?.slice(0, 10) || new Date().toISOString().slice(0, 10),
      },
      posts,
      resolvedUsername,
    };
  } catch {
    return { posts: [] };
  }
}

export async function fetchGithubActivity(username: string, isNameQuery = false): Promise<{ account?: Partial<PlatformAccount>; posts: Post[]; resolvedUsername?: string }> {
  const demoData = getDemoGithubData(username);
  if (demoData) return demoData;

  try {
    const [userResponse, eventsResponse] = await Promise.all([
      fetchWithTimeout(`https://api.github.com/users/${username}`),
      fetchWithTimeout(`https://api.github.com/users/${username}/events/public?per_page=5`),
    ]);

    if (!userResponse.ok) {
      if (isNameQuery) {
        return { posts: [] };
      }
      return await fuzzyGithubSearch(username);
    }

    const user = await userResponse.json();
    const events = eventsResponse.ok ? await eventsResponse.json() : [];

    const posts: Post[] = Array.isArray(events)
      ? events.slice(0, 5).map((event: any) => formatGithubEvent(event))
      : [];

    return {
      account: {
        displayName: user.name || user.login,
        bio: user.bio || "Public GitHub profile found. No bio exposed.",
        profilePicUrl: user.avatar_url,
        followers: user.followers || 0,
        creationDate: user.created_at?.slice(0, 10) || new Date().toISOString().slice(0, 10),
      },
      posts,
      resolvedUsername: user.login,
    };
  } catch {
    return { posts: [] };
  }
}

export async function fetchRedditActivity(username: string): Promise<Post[]> {
  try {
    const response = await fetchWithTimeout(`https://www.reddit.com/user/${username}/submitted.json?limit=5`);
    if (!response.ok) return [];
    const data = await response.json();
    const children = data?.data?.children;
    if (!Array.isArray(children)) return [];

    return children.map((child: { data: { id: string; title: string; selftext?: string; created_utc: number } }) => ({
      id: `reddit-${child.data.id}`,
      platform: "reddit",
      content: [child.data.title, child.data.selftext].filter(Boolean).join(" - ").slice(0, 420),
      postedAt: new Date(child.data.created_utc * 1000).toISOString(),
      flagLevel: scoreText(child.data.title + " " + (child.data.selftext || "")) > 0 ? "SUSPICIOUS" : "NORMAL",
      flagReason: "Keyword match in public Reddit submission.",
      capturedAt: new Date().toISOString(),
    }));
  } catch {
    return [];
  }
}

export async function fetchHackerNewsActivity(username: string): Promise<{ account?: Partial<PlatformAccount>; posts: Post[] }> {
  try {
    const userResp = await fetchWithTimeout(`https://hacker-news.firebaseio.com/v0/user/${username}.json`);
    if (!userResp.ok) return { posts: [] };
    const user = await userResp.json();
    if (!user || user.error) return { posts: [] };

    const submitted: number[] = (user.submitted || []).slice(0, 5);
    const postResults = await Promise.allSettled(
      submitted.map((id) =>
        fetchWithTimeout(`https://hacker-news.firebaseio.com/v0/item/${id}.json`).then((r) => r.json())
      )
    );

    const posts: Post[] = postResults
      .filter((r) => r.status === "fulfilled" && r.value?.title)
      .map((r) => {
        const item = (r as PromiseFulfilledResult<any>).value;
        const content = [item.title, item.text?.replace(/<[^>]+>/g, " ").slice(0, 200)].filter(Boolean).join(" — ");
        return {
          id: `hn-${item.id}`,
          platform: "hackernews",
          content,
          postedAt: new Date((item.time || 0) * 1000).toISOString(),
          flagLevel: scoreText(content) > 0 ? "SUSPICIOUS" : "NORMAL",
          flagReason: scoreText(content) > 0 ? "Risk keyword match in HackerNews submission." : undefined,
          capturedAt: new Date().toISOString(),
        };
      });

    return {
      account: {
        displayName: user.id,
        bio: `HackerNews user since ${new Date((user.created || 0) * 1000).getFullYear()}. Karma: ${user.karma || 0}.`,
        followers: user.karma || 0,
        creationDate: new Date((user.created || 0) * 1000).toISOString().slice(0, 10),
      },
      posts,
    };
  } catch {
    return { posts: [] };
  }
}

export async function fetchDevToActivity(username: string): Promise<{ account?: Partial<PlatformAccount>; posts: Post[] }> {
  try {
    const [userResp, articlesResp] = await Promise.all([
      fetchWithTimeout(`https://dev.to/api/users/by_username?url=${username}`),
      fetchWithTimeout(`https://dev.to/api/articles?username=${username}&per_page=5`),
    ]);
    if (!userResp.ok) return { posts: [] };
    const user = await userResp.json();
    const articles = articlesResp.ok ? await articlesResp.json() : [];

    const posts: Post[] = Array.isArray(articles)
      ? articles.map((a: any) => ({
          id: `devto-${a.id}`,
          platform: "devto",
          content: `${a.title}${a.description ? ` — ${a.description}` : ""}`,
          postedAt: a.published_at || new Date().toISOString(),
          flagLevel: scoreText(a.title + " " + (a.description || "")) > 0 ? "SUSPICIOUS" : "NORMAL",
          flagReason: "Risk keyword in Dev.to article.",
          capturedAt: new Date().toISOString(),
        }))
      : [];

    return {
      account: {
        displayName: user.name || user.username,
        bio: user.summary || "Dev.to profile found.",
        profilePicUrl: user.profile_image_90 || user.profile_image,
        followers: user.followers_count || 0,
        creationDate: user.joined_at?.slice(0, 10) || new Date().toISOString().slice(0, 10),
      },
      posts,
    };
  } catch {
    return { posts: [] };
  }
}

export async function fetchGitLabActivity(username: string): Promise<{ account?: Partial<PlatformAccount>; posts: Post[] }> {
  try {
    const resp = await fetchWithTimeout(`https://gitlab.com/api/v4/users?username=${username}&per_page=1`);
    if (!resp.ok) return { posts: [] };
    const users = await resp.json();
    if (!Array.isArray(users) || users.length === 0) return { posts: [] };
    const user = users[0];

    return {
      account: {
        displayName: user.name || user.username,
        bio: user.bio || "GitLab public profile found.",
        profilePicUrl: user.avatar_url,
        followers: 0,
        creationDate: user.created_at?.slice(0, 10) || new Date().toISOString().slice(0, 10),
      },
      posts: [],
    };
  } catch {
    return { posts: [] };
  }
}

export async function searchWebForSocialProfiles(query: string, capturedAt: string): Promise<{
  accounts: PlatformAccount[];
  education: { institution: string; degree: string; period: string; webEnriched?: boolean; website?: string; description?: string }[];
  experience: { role: string; company: string; period: string; details: string }[];
  hackathons: { name: string; result: string; year: string; source: string }[];
  suggestedProfiles: { name: string; platform: string; handle: string; profileUrl: string; bio?: string; followers?: number; matchScore: number }[];
}> {
  const discoveredAccounts: PlatformAccount[] = [];
  const education: { institution: string; degree: string; period: string; webEnriched?: boolean; website?: string; description?: string }[] = [];
  const experience: { role: string; company: string; period: string; details: string }[] = [];
  const hackathons: { name: string; result: string; year: string; source: string }[] = [];
  const suggestedProfiles: { name: string; platform: string; handle: string; profileUrl: string; bio?: string; followers?: number; matchScore: number }[] = [];

  try {
    const expanded = buildExpandedSearchQuery(query);
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(expanded + " (site:linkedin.com OR site:instagram.com OR site:github.com)")}&num=10`;
    const resp = await fetchWithTimeout(searchUrl, 5000);
    if (!resp.ok) return { accounts: discoveredAccounts, education, experience, hackathons, suggestedProfiles };

    const html = await resp.text();
    const blocks = html.split(/<div[^>]*class="[^"]*(?<![a-zA-Z0-9-])g(?![a-zA-Z0-9-])[^"]*"/gi);
    const resultsMap = new Map<string, { url: string; title: string; snippet: string }>();

    for (let i = 1; i < blocks.length; i++) {
      const block = blocks[i];
      
      const urlMatch = block.match(/href="(\/url\?[^"]+)"/i) || block.match(/href="(https?:\/\/[^"]+)"/i);
      let decodedUrl = '';
      if (urlMatch) {
        const rawUrl = urlMatch[1];
        if (rawUrl.startsWith('/url?')) {
          const qMatch = rawUrl.match(/[?&]q=([^&"]+)/);
          if (qMatch) {
            try {
              decodedUrl = decodeURIComponent(qMatch[1]);
            } catch (e) {}
          }
        } else if (rawUrl.startsWith('http') && !rawUrl.includes('google.com')) {
          decodedUrl = rawUrl;
        }
      }
      
      const h3Match = block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
      let title = '';
      if (h3Match) {
        title = h3Match[1].replace(/<[^>]+>/g, '').trim();
      } else {
        const firstAnchorText = block.match(/<a[^>]*>([\s\S]*?)<\/a>/i);
        if (firstAnchorText) {
          title = firstAnchorText[1].replace(/<[^>]+>/g, '').trim();
        }
      }
      
      const snippetMatch = block.match(/<div[^>]*class="[^"]*BNeawe[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                           block.match(/<div[^>]*class="[^"]*VwiC3b[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                           block.match(/<div[^>]*class="[^"]*IsZvec[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                           block.match(/<span[^>]*class="[^"]*aCOpRe[^"]*"[^>]*>([\s\S]*?)<\/span>/i) ||
                           block.match(/<div[^>]*class="[^"]*lEBKkf[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
      const snippet = snippetMatch ? snippetMatch[1].replace(/<[^>]+>/g, '').trim() : '';
      
      if (decodedUrl && (title || snippet)) {
        resultsMap.set(decodedUrl, { url: decodedUrl, title, snippet });
      } else if (decodedUrl) {
        resultsMap.set(decodedUrl, { url: decodedUrl, title: title || 'Profile', snippet: snippet || '' });
      } else if (resultsMap.size > 0 && (title || snippet)) {
        const lastKey = Array.from(resultsMap.keys()).pop();
        if (lastKey) {
          const existing = resultsMap.get(lastKey)!;
          resultsMap.set(lastKey, {
            url: existing.url,
            title: existing.title && existing.title !== 'Profile' ? existing.title : title,
            snippet: existing.snippet ? existing.snippet : snippet
          });
        }
      }
    }

    for (const [url, item] of resultsMap.entries()) {
      const lowerUrl = url.toLowerCase();
      
      let platform: "linkedin" | "instagram" | "github" | "" = "";
      if (lowerUrl.includes("linkedin.com/in/")) {
        platform = "linkedin";
      } else if (lowerUrl.includes("instagram.com/")) {
        platform = "instagram";
      } else if (lowerUrl.includes("github.com/")) {
        platform = "github";
      }
      
      if (!platform) continue;
      
      let handle = "";
      if (platform === "linkedin") {
        handle = url.split("/in/")[1]?.split("/")[0]?.split("?")[0] || "";
      } else if (platform === "instagram") {
        if (lowerUrl.includes("/p/") || lowerUrl.includes("/reel/") || lowerUrl.includes("/explore/")) continue;
        handle = url.split("instagram.com/")[1]?.split("/")[0]?.split("?")[0] || "";
      } else if (platform === "github") {
        handle = url.split("github.com/")[1]?.split("/")[0]?.split("?")[0] || "";
        if (["topics", "trending", "features", "marketplace", "pricing", "search", "explore", "about"].includes(handle.toLowerCase())) {
          continue;
        }
      }
      
      if (!handle || handle.length < 2) continue;
      
      let followers = 0;
      if (platform === "instagram") {
        const matchInsta = item.snippet.match(/(\d+[\d,.]*)\ s*(?:Followers|followers)/i);
        if (matchInsta) {
          followers = parseInt(matchInsta[1].replace(/,/g, ''));
        } else {
          followers = 280;
        }
      } else if (platform === "linkedin") {
        const matchConn = item.snippet.match(/(\d+[\d,.]*[+kKmM]?)\s*(?:connections|Connections|followers|Followers)/i);
        if (matchConn) {
          const rawVal = matchConn[1].toLowerCase();
          if (rawVal.includes('k')) followers = parseFloat(rawVal) * 1000;
          else if (rawVal.includes('m')) followers = parseFloat(rawVal) * 1000000;
          else followers = parseInt(rawVal.replace(/[+,]/g, ''));
        } else {
          followers = 500;
        }
      } else {
        followers = 45;
      }
      
      const collegeKeywords = ["college", "university", "institute", "school", "bmsce", "rvce", "iiit", "iit", "pesit", "msrit", "bnmit", "vtu", "autonomous"];
      const workKeywords = ["intern", "engineer", "analyst", "developer", "manager", "designer", "consultant", "architect", "lead", "founder", "cto", "ceo"];
      const hackathonKeywords = ["hackathon", "hack", "devfest", "ideathon", "buildathon", "smart india hackathon", "sih", "mlh", "winner", "finalist"];

      const eduMatch = item.snippet.match(/Education:\s*([^·\n|]+)/i);
      if (eduMatch) {
        const institution = eduMatch[1].replace(/&middot;/g, '').trim();
        if (institution && institution.length > 2 && !education.some(e => e.institution.toLowerCase() === institution.toLowerCase())) {
          education.push({
            institution,
            degree: "Public Academic Record",
            period: "Sourced via LinkedIn Index",
            webEnriched: false,
          });
        }
      }
      
      const expMatch = item.snippet.match(/Experience:\s*([^·\n|]+)/i);
      if (expMatch) {
        const company = expMatch[1].replace(/&middot;/g, '').trim();
        if (company && company.length > 2 && !experience.some(e => e.company.toLowerCase() === company.toLowerCase())) {
          experience.push({
            role: "Professional Role",
            company,
            period: "Sourced via LinkedIn Index",
            details: `Identified public role: ${company}`
          });
        }
      }

      const segments = item.snippet.split(/\s*[-|·|•|\|]\s*/);
      for (const seg of segments) {
        const cleanSeg = seg.trim();
        const lowerSeg = cleanSeg.toLowerCase();
        
        const cleanVal = cleanSeg
          .replace(/^(?:student\s+at|studied\s+at|alumni\s+of|alumnus\s+of|pursuing\s+[a-zA-Z\s]+\s+at|education:\s*|profile\s+of\s+|working\s+as\s+a\s+|works\s+at\s+)/i, "")
          .trim();

        if (collegeKeywords.some(cw => lowerSeg.includes(cw))) {
          if (cleanVal.length > 4 && !education.some(e => e.institution.toLowerCase().includes(cleanVal.toLowerCase()) || cleanVal.toLowerCase().includes(e.institution.toLowerCase()))) {
            education.push({
              institution: cleanVal,
              degree: "Public Academic Record",
              period: "Sourced via Search Index",
              webEnriched: false,
            });
          }
        }

        if (workKeywords.some(ww => lowerSeg.includes(ww)) && !lowerSeg.includes("student") && !lowerSeg.includes("education")) {
          if (cleanVal.length > 4 && !experience.some(exp => exp.role.toLowerCase().includes(cleanVal.toLowerCase()) || cleanVal.toLowerCase().includes(exp.role.toLowerCase()))) {
            experience.push({
              role: cleanVal,
              company: "Public Professional Role",
              period: "Sourced via Search Index",
              details: cleanVal
            });
          }
        }

        if (hackathonKeywords.some(hw => lowerSeg.includes(hw))) {
          const yearMatch = cleanSeg.match(/\b(20\d{2})\b/);
          const year = yearMatch ? yearMatch[1] : new Date().getFullYear().toString();
          const resultMatch = cleanSeg.match(/\b(winner|finalist|runner[- ]up|participant|1st|2nd|3rd)\b/i);
          const result = resultMatch ? resultMatch[1].charAt(0).toUpperCase() + resultMatch[1].slice(1) : "Participant";
          const hackName = cleanVal.replace(/\b(winner|finalist|runner[- ]up|participant|1st|2nd|3rd|in|at|of|the)\b/gi, "").trim() || cleanSeg;

          if (hackName.length > 3 && !hackathons.some(h => h.name.toLowerCase() === hackName.toLowerCase())) {
            hackathons.push({
              name: hackName,
              result,
              year,
              source: "Search Index Annotation"
            });
          }
        }
      }
      
      const existsIdx = discoveredAccounts.findIndex(a => a.platform === platform && a.username.toLowerCase() === handle.toLowerCase());
      if (existsIdx === -1) {
        discoveredAccounts.push({
          id: `${platform}-${handle}-${Date.now()}`,
          platform,
          username: handle,
          profileUrl: url,
          displayName: item.title.split("|")[0].split(" - ")[0].trim() || `${platform} Profile`,
          bio: item.snippet.slice(0, 160),
          followers,
          creationDate: new Date().toISOString().slice(0, 10),
          confidence: "PROBABLE",
          capturedAt,
          reason: `Discovered via social crawling index query.`
        });
      }
    }
  } catch (err) {
    console.error("Dynamic web search crawler failed:", err);
  }

  // ── Progressive Name Prefix Search ─────────────────────────────────────
  try {
    const cleanName = query.trim().replace(/^@/, "");
    const candidateNames = new Set<string>();
    
    let emailPrefix = cleanName;
    if (cleanName.includes("@")) {
      emailPrefix = cleanName.split("@")[0];
    }
    candidateNames.add(emailPrefix);
    
    const resolvedDisplayName = displayNameFromQuery(emailPrefix);
    if (resolvedDisplayName && resolvedDisplayName.toLowerCase() !== emailPrefix.toLowerCase()) {
      candidateNames.add(resolvedDisplayName);
    }
    
    const rawParts = emailPrefix.split(/[._\-\s]+/);
    if (rawParts.length > 1) {
      for (const part of rawParts) {
        if (part.length >= 3) {
          candidateNames.add(part);
        }
      }
    }
    
    const prefixes: string[] = [];
    for (const name of candidateNames) {
      const minLen = Math.max(3, Math.ceil(name.length * 0.4));
      for (let len = minLen; len <= name.length; len++) {
        const p = name.slice(0, len).trim();
        if (p.length >= 3) {
          prefixes.push(p);
        }
      }
    }
    
    for (const name of candidateNames) {
      if (name.includes(" ")) {
        const parts = name.split(" ");
        if (parts.length >= 2) {
          const firstPart = parts[0];
          const secondPart = parts[1];
          for (let l = 1; l <= secondPart.length; l++) {
            prefixes.push(`${firstPart} ${secondPart.slice(0, l)}`);
          }
        }
      }
    }

    const uniquePrefixes = [...new Set(prefixes)].slice(-8);

    const searchPromises = uniquePrefixes.map(async (prefix) => {
      try {
        const prefixUrl = `https://www.google.com/search?q=${encodeURIComponent(
          `"${prefix}" site:linkedin.com/in OR site:instagram.com OR site:github.com OR site:twitter.com`
        )}&num=10`;
        const prefixResp = await fetchWithTimeout(prefixUrl, 4000);
        if (!prefixResp.ok) return [];

        const prefixHtml = await prefixResp.text();
        const pBlocks = prefixHtml.split(/<div[^>]*class="[^\"]*((?<![a-zA-Z0-9-])g(?![a-zA-Z0-9-]))[^"]*"/gi);
        const results: typeof suggestedProfiles = [];

        for (let bi = 1; bi < pBlocks.length; bi++) {
          const blk = pBlocks[bi];
          const urlM = blk.match(/href="(\/url\?[^"]+)"/i) || blk.match(/href="(https?:\/\/[^"]+)"/i);
          if (!urlM) continue;

          let dUrl = "";
          const rawU = urlM[1];
          if (rawU.startsWith("/url?")) {
            const qm = rawU.match(/[?&]q=([^&"]+)/);
            if (qm) { try { dUrl = decodeURIComponent(qm[1]); } catch (_) {} }
          } else if (rawU.startsWith("http") && !rawU.includes("google.com")) {
            dUrl = rawU;
          }
          if (!dUrl) continue;

          const lu = dUrl.toLowerCase();
          let spPlatform = "";
          let spHandle = "";

          if (lu.includes("linkedin.com/in/")) {
            spPlatform = "linkedin";
            spHandle = dUrl.split("/in/")[1]?.split("/")[0]?.split("?")[0] || "";
          } else if (lu.includes("instagram.com/") && !lu.includes("/p/") && !lu.includes("/reel/")) {
            spPlatform = "instagram";
            spHandle = dUrl.split("instagram.com/")[1]?.split("/")[0]?.split("?")[0] || "";
          } else if (lu.includes("github.com/")) {
            const gh = dUrl.split("github.com/")[1]?.split("/")[0]?.split("?")[0] || "";
            const bl = ["topics","trending","features","marketplace","pricing","search","explore","about"];
            if (!bl.includes(gh.toLowerCase())) { spPlatform = "github"; spHandle = gh; }
          } else if (lu.includes("twitter.com/") || lu.includes("x.com/")) {
            const tw = dUrl.split(/twitter\.com\/|x\.com\//)[1]?.split("/")[0]?.split("?")[0] || "";
            const bl = ["home","explore","notifications","messages","i","search","hashtag","settings"];
            if (!bl.includes(tw.toLowerCase()) && tw.length > 1) { spPlatform = "twitter"; spHandle = tw; }
          }

          if (!spPlatform || !spHandle || spHandle.length < 2) continue;

          const h3M = blk.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
          const spTitle = h3M ? h3M[1].replace(/<[^>]+>/g, "").trim() : spHandle;
          const snipM = blk.match(/<div[^>]*class="[^"]*BNeawe[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                        blk.match(/<div[^>]*class="[^"]*VwiC3b[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
          const spBio = snipM ? snipM[1].replace(/<[^>]+>/g, "").trim() : "";

          const normHandle = spHandle.toLowerCase().replace(/[^a-z0-9]/g, "");
          const normPrefix = prefix.toLowerCase().replace(/[^a-z0-9]/g, "");
          const normTitle  = spTitle.toLowerCase().replace(/[^a-z0-9\s]/g, "");
          const mScore = normHandle.startsWith(normPrefix)
            ? Math.round((normPrefix.length / Math.max(normHandle.length, 1)) * 100)
            : normTitle.includes(normPrefix)
            ? Math.round((normPrefix.length / Math.max(normTitle.length, 1)) * 80)
            : 25;

          const spUrl = spPlatform === "linkedin" ? `https://www.linkedin.com/in/${spHandle}` :
                        spPlatform === "instagram" ? `https://www.instagram.com/${spHandle}` :
                        spPlatform === "github" ? `https://github.com/${spHandle}` :
                        `https://twitter.com/${spHandle}`;

          let spFollowers = 0;
          const fM = spBio.match(/(\d+[\d,.]*[kKmM]?)\s*(?:followers|connections)/i);
          if (fM) {
            const fv = fM[1].toLowerCase();
            spFollowers = fv.includes("k") ? parseFloat(fv) * 1000 :
                          fv.includes("m") ? parseFloat(fv) * 1000000 :
                          parseInt(fv.replace(/[+,]/g, "")) || 0;
          }

          results.push({
            name: spTitle.split("|")[0].split(" - ")[0].trim() || spHandle,
            platform: spPlatform,
            handle: spHandle,
            profileUrl: spUrl,
            bio: spBio.slice(0, 150),
            followers: spFollowers,
            matchScore: Math.min(100, mScore),
          });
        }
        return results;
      } catch (_) {
        return [];
      }
    });

    const allResults = await Promise.all(searchPromises);
    for (const prefixResults of allResults) {
      for (const res of prefixResults) {
        const alreadyIn = suggestedProfiles.some(sp =>
          sp.platform === res.platform && sp.handle.toLowerCase() === res.handle.toLowerCase()
        );
        if (!alreadyIn) {
          suggestedProfiles.push(res);
        }
      }
    }

    suggestedProfiles.sort((a, b) => b.matchScore - a.matchScore);
  } catch (err) {
    console.error("Progressive prefix search failed:", err);
  }

  // ── Targeted LinkedIn Education Dork ───────────────────────────────────
  if (education.length === 0) {
    try {
      const searchName = query.includes("@") ? displayNameFromQuery(query.split("@")[0]) : displayNameFromQuery(query);
      const eduDorkUrl = `https://www.google.com/search?q=${encodeURIComponent(
        `site:linkedin.com/in "${searchName}" (college OR university OR institute OR B.Tech OR B.E OR engineering OR MBA)`
      )}&num=5`;
      const eduResp = await fetchWithTimeout(eduDorkUrl, 5000);
      if (eduResp.ok) {
        const eduHtml = await eduResp.text();
        const eduBlocks = eduHtml.split(/<div[^>]*class="[^\"]*((?<![a-zA-Z0-9-])g(?![a-zA-Z0-9-]))[^"]*"/gi);

        for (let ei = 1; ei < eduBlocks.length; ei++) {
          const blk = eduBlocks[ei];
          const snipM = blk.match(/<div[^>]*class="[^"]*BNeawe[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                        blk.match(/<div[^>]*class="[^"]*VwiC3b[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                        blk.match(/<span[^>]*class="[^"]*aCOpRe[^"]*"[^>]*>([\s\S]*?)<\/span>/i);
          if (!snipM) continue;
          const snippet = snipM[1].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

          const eduKw = ["college", "university", "institute", "b.tech", "b.e", "m.tech", "mba", "engineering", "iiit", "iit", "nit", "vtu", "pesit", "bmsce", "rvce"];
          const segs = snippet.split(/\s*[-|·•]\s*/);
          for (const seg of segs) {
            const low = seg.toLowerCase();
            if (eduKw.some(ek => low.includes(ek))) {
              const val = seg.replace(/^(?:student at|studied at|alumni of|pursuing [a-zA-Z\s]+ at|education:\s*)/i, "").trim();
              if (val.length > 5 && !education.some(e => e.institution.toLowerCase().includes(val.toLowerCase().slice(0, 12)))) {
                education.push({
                  institution: val.slice(0, 120),
                  degree: "Public Academic Record",
                  period: "LinkedIn Education Dork",
                  webEnriched: false,
                });
              }
            }
          }
          const eduM = snippet.match(/Education:\s*([^·\n|]+)/i);
          if (eduM) {
            const inst = eduM[1].trim();
            if (inst.length > 5 && !education.some(e => e.institution.toLowerCase().includes(inst.toLowerCase().slice(0, 12)))) {
              education.push({
                institution: inst.slice(0, 120),
                degree: "Public Academic Record",
                period: "LinkedIn Education Dork",
                webEnriched: false,
              });
            }
          }
        }
      }
    } catch (err) {
      console.error("LinkedIn education dork failed:", err);
    }
  }

  // ── Targeted LinkedIn Experience Dork ───────────────────────────────────
  if (experience.length === 0) {
    try {
      const searchName = query.includes("@") ? displayNameFromQuery(query.split("@")[0]) : displayNameFromQuery(query);
      const expDorkUrl = `https://www.google.com/search?q=${encodeURIComponent(
        `site:linkedin.com/in "${searchName}" (engineer OR developer OR manager OR analyst OR consultant OR founder OR specialist OR works OR experience)`
      )}&num=5`;
      const expResp = await fetchWithTimeout(expDorkUrl, 5000);
      if (expResp.ok) {
        const expHtml = await expResp.text();
        const expBlocks = expHtml.split(/<div[^>]*class="[^\"]*((?<![a-zA-Z0-9-])g(?![a-zA-Z0-9-]))[^"]*"/gi);

        for (let ei = 1; ei < expBlocks.length; ei++) {
          const blk = expBlocks[ei];
          const snipM = blk.match(/<div[^>]*class="[^"]*BNeawe[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                        blk.match(/<div[^>]*class="[^"]*VwiC3b[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
                        blk.match(/<span[^>]*class="[^"]*aCOpRe[^"]*"[^>]*>([\s\S]*?)<\/span>/i);
          if (!snipM) continue;
          const snippet = snipM[1].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

          const workKw = ["engineer", "developer", "manager", "analyst", "consultant", "founder", "specialist", "intern", "lead", "architect", "designer", "officer"];
          const segs = snippet.split(/\s*[-|·•]\s*/);
          for (const seg of segs) {
            const low = seg.toLowerCase();
            if (workKw.some(wk => low.includes(wk)) && !low.includes("student") && !low.includes("education")) {
              const val = seg.replace(/^(?:student at|studied at|alumni of|pursuing [a-zA-Z\s]+ at|working as a |works at |experience:\s*)/i, "").trim();
              if (val.length > 5 && !experience.some(e => e.role.toLowerCase().includes(val.toLowerCase().slice(0, 12)))) {
                experience.push({
                  role: val.slice(0, 120),
                  company: "Public Professional Role",
                  period: "LinkedIn Experience Dork",
                  details: `Identified public role: ${val}`,
                });
              }
            }
          }
        }
      }
    } catch (err) {
      console.error("LinkedIn experience dork failed:", err);
    }
  }

  return { accounts: discoveredAccounts, education, experience, hackathons, suggestedProfiles };
}
